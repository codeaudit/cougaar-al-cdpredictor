package org.cougaar.tools.techspecs.events;

import org.cougaar.cpe.qos.MeasurementChain;
import org.cougaar.tools.techspecs.ActionEventSpec;

import java.io.Serializable;

/**
 *  This encapsulates a message either an input message or a timer message.
 */
public class ActionEvent implements Serializable
{
    public ActionEvent(int type)
    {
        this.type = type;
    }

    public int getType()
    {
        return type;
    }

    /**
     * This is filled in automatically by the callback action (based on generated code.)
     *
     * @param spec
     */
    public void setSpec(ActionEventSpec spec)
    {
        this.spec = spec;
    }

    public ActionEventSpec getSpec()
    {
        return spec;
    }

    public String toString() {
        StringBuffer buf = new StringBuffer() ;
        buf.append( "[" ) ;
        paramString( buf );
        buf.append( "]") ;
        return buf.toString() ;
    }

    public void paramString( StringBuffer buf ) {
    }


    protected MeasurementChain measurements = new MeasurementChain();
    transient ActionEventSpec spec ;
    int type ;

    protected long sentTimeStamp ;
    protected long receivedTimeStamp ;
    protected long startProcessedTimestamp ;
    protected long endProcessedTimestamp ;
}
