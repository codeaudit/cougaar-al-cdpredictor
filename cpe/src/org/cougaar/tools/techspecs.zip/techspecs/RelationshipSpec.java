package org.cougaar.tools.techspecs;

import org.cougaar.planning.ldm.plan.RelationshipImpl;

import java.io.Serializable;
import java.util.HashMap;

/**
 * This is made to describe the relationship between two
 * RoleSpec functions.  It is akin to the org.cougaar.planning.ldm.plan.Relationship
 * interface except that it simply names the role rather than requiring a role
 * data structure.
 *
 * <p> This is not derived from TechSpec because it is does not fall in the TechSpec containment
 * hierarchy.
 */
public class RelationshipSpec implements Serializable
{
    public static final class RoleInfo implements Serializable {
        public static final int CARDINALITY_N = -1 ;

        public RoleInfo(int cardinality, String roleName, boolean required)
        {
            this.cardinality = cardinality;
            this.peerRoleName = roleName;
            this.required = required;
        }


        public int getCardinality()
        {
            return cardinality;
        }

        public boolean isRequired()
        {
            return required;
        }

        public String getName()
        {
            return peerRoleName;
        }

        /**
         * The name of the peer role.
         */
        private String peerRoleName ;

        /**
         * Does this peer role need to be satisfied for this role to be valid?
         */
        private boolean required ;

        /**
         * The cardinality of the role within the
         */
        private int cardinality ;
    }

    public String getRelationshipName()
    {
        return relationshipName;
    }

    public RoleInfo getRoleInfo( String role )
    {
        return (RoleInfo) roleInfo.get( role );
    }

    public void addRoleInfo( RoleInfo info ) {
        roleInfo.put( info.getName(), info ) ;
    }

    /**
     * The name of the relationship, e.g. "BNSuperiorCPYSubordinate"
     *
     */
    String relationshipName ;

    HashMap roleInfo = new HashMap();
}
