package org.cougaar.tools.techspecs;

import org.cougaar.core.adaptivity.OperatingMode;
import org.cougaar.tools.techspecs.events.ActionEvent;

import java.util.ArrayList;

/**
 *
 *
 */
public abstract class ActionModelFunction
{

    public ActionModelFunction(ActionSpec parentSpec)
    {
        this.parentSpec = parentSpec;
    }

    public ActionSpec getParentSpec()
    {
        return parentSpec;
    }

    public abstract boolean accept( ActionEvent input ) ;

    /**
     * This model function
     *
     * @param s
     * @param opModes
     * @param input
     * @param result
     * @return
     */
    public abstract boolean process( RoleStateSpec s, OperatingMode[] opModes, ActionEvent input, ArrayList result ) ;

    public int getNumOpModeDependencies( ) {
        return opModeDependencies.size() ;
    }

    public String getOpModeDependencyName( int i ) {
        return (String) opModeDependencies.get(i) ;
    }

    protected ArrayList opModeDependencies = new ArrayList();
    protected ActionSpec parentSpec ;

}
