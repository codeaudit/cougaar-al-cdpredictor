package org.cougaar.tools.techspecs;

import java.util.ArrayList;

public class PluginSpec extends TechSpec
{
    /**
     * @param instanceName
     * @param className
     * @param parent
     */
    public PluginSpec(String instanceName, String className, TechSpec parent )
    {
        super(instanceName, parent, TechSpec.TYPE_PLUGIN, TechSpec.LAYER_APPLICATION );
        this.className = className ;
    }

    public String getClassName()
    {
        return className;
    }

    public int getNumOpModes() {
        return opmodes.size() ;
    }

    public void addRole( RoleImplSpec rs ) {
        roles.add( rs ) ;
    }

    public RoleImplSpec getRole( int i ) {
        return (RoleImplSpec) roles.get(i) ;
    }

    public int getNumRoles() {
        return roles.size() ;
    }

    String className ;

    /**
     * A list of RoleSpec objects.
     */
    ArrayList roles = new ArrayList() ;

    /**
     * Operating modes. Generated as perating mode conditions on the BB.
     */
    ArrayList opmodes = new ArrayList() ;

//    /**
//     *  This is a set of measurements associated with this plugin.  Measurement code
//     *  is generated automatically and inserted associated with actions.
//     */
//    ArrayList measurements = new ArrayList() ;
}
