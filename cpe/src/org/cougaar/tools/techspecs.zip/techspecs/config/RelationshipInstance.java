package org.cougaar.tools.techspecs.config;

import org.cougaar.tools.techspecs.RoleImplSpec;
import org.cougaar.tools.techspecs.RelationshipSpec;

import java.io.Serializable;
import java.util.HashMap;

public class RelationshipInstance implements Serializable
{

    /**
     * Connect the PluginInstance (instantiated within an agent) with a particular role.
     * @param spec
     * @param rspec
     */
    public void addRoleInstance( PluginInstanceSpec spec, RoleImplSpec rspec ) {
        relationshipSpec.getRoleInfo( rspec.getName() ) ;

    }

    RelationshipSpec relationshipSpec ;

    HashMap roleInstanceToRoleSpecMap = new HashMap() ;
}
