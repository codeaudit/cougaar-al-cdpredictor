package org.cougaar.tools.techspecs.results;

import org.cougaar.cpe.qos.MeasurementPoint;

/**
 * A measurement point that takes ActionResult entities of a certain type.
 */
public class ActionMeasurementPoint
{
    public ActionMeasurementPoint(String name)
    {
        this.name = name ;
    }

    // Observed elapsed time measurement statistics
    float averageElapsedTime ;

    protected String name ;
}
